	project "BulletSoftBody"
		
	kind "StaticLib"
	
	includedirs {
		"..",
	}
	files {
		"**.cpp",
		"**.h"
	}